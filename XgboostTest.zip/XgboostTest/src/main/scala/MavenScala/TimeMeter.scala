package MavenScala

/**
  * Created by zhaowl on 2017/1/18.
  */
object TimeMeter {
  var startTime:Long = 0

  def restart() = {
    startTime = System.currentTimeMillis()
  }

  def stop():Long = {
    System.currentTimeMillis() - startTime
  }
}

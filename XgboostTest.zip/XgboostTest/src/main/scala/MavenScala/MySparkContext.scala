package MavenScala

import org.apache.spark.{SparkConf, SparkContext};
/**
  * Created by zhaowl on 2016/12/14.
  */
object MySparkContext {
  val conf = new SparkConf().setAppName(ConfigManager.conf("appName"))
  val sc = new SparkContext(conf);
  val sqlContext = new org.apache.spark.sql.SQLContext(sc);
  val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc);
}

package MavenScala

//import ml.dmlc.xgboost4j.LabeledPoint
import ml.dmlc.xgboost4j.java.Rabit
import ml.dmlc.xgboost4j.scala.DMatrix
import ml.dmlc.xgboost4j.scala.spark.{XGBoost, XGBoostModel}
import org.apache.spark.TaskContext
import org.apache.spark.mllib.linalg.SparseVector

import scala.xml.XML
//import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.ml.feature.VectorAssembler

import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint

import scala.collection.mutable.ArrayBuffer
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}



/**
 * A Main to run Camel with MyRouteBuilder
 */
object MyRouteMain /*extends RouteBuilderSupport*/ {

  def main(args: Array[String]) {

    /* Load configurations(DataTables, ConfigManager, XGBConfigMap) from files */
    println("========= Loading Configuration File Start =========")
    TimeMeter.restart()
    loadConfig()
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Loading Configuration File Ended =========")

    println()
    println("========= Print Config Manager Start =========")
    TimeMeter.restart()
    ConfigManager.conf.foreach(println)
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Print Config Manager Ended =========")

    // prepare sample data
    var rawSampleTableDF:DataFrame = null
    if(ConfigManager.conf("loadDataFromSavedCombinedWideTable") == "true") {
      println()
      println("========= Load Sample Data From Saved Start =========")
      TimeMeter.restart()
      rawSampleTableDF = MySparkContext.hiveContext.read.load(ConfigManager.conf("saveDFPath"))
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Load Sample Data From Saved Ended =========")
    } else {
      println()
      println("========= Load Sample Data From Combining Tables Start =========")
      TimeMeter.restart()
      rawSampleTableDF = prepareWideSampleTableDF().repartition(ConfigManager.conf("repartitionNum1").toInt)
      rawSampleTableDF.show()
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Load Sample Data From Combining Tables Ended =========")

      println()
      println("========= Save Combined Sample Data Start =========")
      TimeMeter.restart()
      rawSampleTableDF.write.mode("overwrite").save(ConfigManager.conf("saveDFPath"))
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Save Combined Sample Data Start =========")
    }

    // split data into training and testing according to date(usually 7days training and last day for testing)
    println()
    println("========= Split Data Into Training And Teting By Date Start =========")
    TimeMeter.restart()
    val dataSplitTp = splitData(rawSampleTableDF)
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Split Data Into Training And Teting By Date End =========")

    // sampling the negative samples to balance the positive and negative samples
    println()
    println("========= Sampling Data Start =========")
    TimeMeter.restart()
    val afterSamplingTp2 = sampling(dataSplitTp._1.drop("d"), ConfigManager.conf("underSampleRate").toDouble, 11L)
    val scale_pos_weight = afterSamplingTp2._2
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Sampling Data Ended =========")

    println()
    println("========= start to convert training samples to rddTrain =========")
    TimeMeter.restart()
    /*val rddTrain = convertToRDDofMLBLabeledPoint(afterSamplingTp2._1)*/
    val rddTrain = convertToRDDofMLBSparseVecLabeledPoint(afterSamplingTp2._1)
    println(" SparsedVec LabeledPoint Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    rddTrain.take(20).foreach(println)
    TimeMeter.restart()
    //MySparkContext.hiveContext.createDataFrame(rddTrain).show()
    val rddTrainForPrediction = convert(rddTrain, false)
    println(" LabeledPoint Type Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= rddTrain converting finished finished =========")

    // convert testing DataFrame into RDD[LabeledPoint]
    println()
    println("========= Start to convert testing samples to testingRDDOfLabeledPoint=========")
    TimeMeter.restart()
    /*val rddTest = convertToRDDofMLBLabeledPoint(dataSplitTp._2.drop("d"))*/
    val rddTest = convertToRDDofMLBSparseVecLabeledPoint(dataSplitTp._2.drop("d"))
    println(" SparsedVec LabeledPoint Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    TimeMeter.restart()
    val rddTestForPrediction = convert(rddTest, false)
    //val rddTestForPrediction = convertToRDDofDMLCLabeledPoint(dataSplitTp._2.drop("d"))
    println(" LabeledPoint Type Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= testingRDDOfLabeledPoint converting finished =========")


    // Xgboost model parameters
    /*Handle Imbalanced Dataset
    For common cases such as ads clickthrough log, the dataset is extremely imbalanced.
    This can affect the training of xgboost model, and there are two ways to improve it.

    If you care only about the ranking order (AUC) of your prediction
      Balance the positive and negative weights, via scale_pos_weight
      Use AUC for evaluation
    If you care about predicting the right probability
      In such a case, you cannot re-balance the dataset
    In such a case, set parameter max_delta_step to a finite number (say 1) will help convergence*/
    println()
    println("========= XGBoost Initial Parameter Map Start =========")
    var configMap = List(
      "silent" -> XGBConfig.confMap("silent").toInt,
      "eta" -> XGBConfig.confMap("eta").toDouble, // this is learning rate, normally it should be between 0.05~0.3 or typical value 0.01~0.2, this parameters should be paired with number of trees(nRounds)
      "max_depth" -> XGBConfig.confMap("max_depth").toInt, // typical value 3~10
      "objective" -> XGBConfig.confMap("objective"),
      "gamma" -> XGBConfig.confMap("gamma").toInt,
      "min_child_weight" -> XGBConfig.confMap("min_child_weight").toInt,
      "scale_pos_weight" -> scale_pos_weight, // controls the imbalanced pos and neg samples, usually sum(negative cases) / sum(positive cases), defualt is 1
      "max_delta_step" -> XGBConfig.confMap("max_delta_step").toInt,
      "subsample" -> XGBConfig.confMap("subsample").toDouble, // typical 0.5~1
      "colsample_bytree" -> XGBConfig.confMap("colsample_bytree").toDouble, // typical 0.5~1
      "eval_metric" -> XGBConfig.confMap("eval_metric")).toMap;
    var round:Int = XGBConfig.confMap("round").toInt // should be considered with learning rate together(eta), the bigger the learning rate the smaller the round should be.
    val nWorkers:Int = ConfigManager.conf("numWorker").toInt // should set to number of partitions from config file, default is 0 which means the number of partitions will be taken as number of workers
    configMap.foreach(println)
    println("round: " + round)
    println("nWorkers: " + nWorkers)
    println("========= XGBoost Initial Parameter Map Ended =========")

    var modifiedParamName = "round"
    var allRoundIterated = false
    //var bestResult = (Map[String, Any], Integer, String, Boolean)
    while (!allRoundIterated) {
      // train model
      /**
        * train XGBoost model with the RDD-represented data
        * @param trainingData the trainingset represented as RDD
        * @param params Map containing the configuration entries
        * @param round the number of iterations
        * @param nWorkers the number of xgboost workers, 0 by default which means that the number of
        *                 workers equals to the partition number of trainingData RDD
        * @param obj the user-defined objective function, null by default
        * @param eval the user-defined evaluation function, null by default
        * @param useExternalMemory indicate whether to use external memory cache, by setting this flag as
        *                           true, the user may save the RAM cost for running XGBoost within Spark
        * @param missing the value represented the missing value in the dataset
        * @throws ml.dmlc.xgboost4j.java.XGBoostError when the model training is failed
        * @return XGBoostModel when successful training
        */
      println()
      println("========= XGBoost Training Start =========")
      TimeMeter.restart()
      val xgBoostModel = XGBoost.train(rddTrain.repartition(ConfigManager.conf("repartitionNum").toInt), configMap, round, nWorkers, null, null, false/*, Float.NaN*/)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= XGBoost Training Ended =========")

      /*println("========= Load XGBoost Model Start =========")
      val xgBoostModel = XGBoost.loadModelFromHadoopFile(ConfigManager.conf("saveModelPath"))(MySparkContext.sc)
      println("========= Load XGBoost Model Ended =========")*/

      println()
      println("========= Feature Score Start =========")
      TimeMeter.restart()
      val featureScoreMap = xgBoostModel.booster.getFeatureScore()
      /*featureScoreMap.foreach(println)*/
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Feature Score Ended =========")

      // dump model
      println()
      println("========= DumpModel(xgBoostModel) Start =========")
      TimeMeter.restart()
      val strModel = dumpModel(xgBoostModel)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= DumpModel Ended =========")

      // save model
      println()
      println("========= SaveModel(" + ConfigManager.conf("saveModelPath") + ", xgBoostModel) Start =========")
      TimeMeter.restart()
      saveModel(ConfigManager.conf("saveModelPath"), xgBoostModel)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= SaveModel(" + ConfigManager.conf("saveModelPath") + ", xgBoostModel) Ended =========")

      println()
      println("========= Start to predict TRAINING data=========")
      TimeMeter.restart()
      val zipFileTrain = labelPredict(rddTrainForPrediction, false, xgBoostModel)
      println(" Label Predict Time Spent: " + TimeMeter.stop() + " milliseconds")
      TimeMeter.restart()
      val trainDataAUC = auc(zipFileTrain)
      println(" AUC Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= TRAIN data auc by labelPredict: " + trainDataAUC + "=========")

      println()
      println("========= Start to predict TEST data=========")
      TimeMeter.restart()
      val zipFileTest = labelPredict(rddTestForPrediction, false, xgBoostModel)
      println(" Label Predict Time Spent: " + TimeMeter.stop() + " milliseconds")
      TimeMeter.restart()
      val testDataAUC = auc(zipFileTest)
      println(" AUC Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= TEST data auc by labelPredict: " + testDataAUC + "=========")

      // update grid search paramMap
      XGBoostParamGen.updateXGBParams(testDataAUC, modifiedParamName, round, configMap)

      println()
      println("========= XGBoost Parameter Map Loop Start =========")
      configMap.foreach(println)
      println("round: " + round)
      println("Train AUC: (" + trainDataAUC + ") Test AUC: (" + testDataAUC + ")")
      println()
      XGBoostParamGen.gridSearchParamsMap.foreach(println)
      println("========= XGBoost Parameter Map Loop Ended =========")

      // get new parameters for next training iteration
      val newXGBParamsResult = XGBoostParamGen.getGridSearchUpdatedXGBParams(configMap, round, "eta")
      configMap = newXGBParamsResult._1
      round = newXGBParamsResult._2
      modifiedParamName = newXGBParamsResult._3
      allRoundIterated = newXGBParamsResult._4

      println()
      println("=========model over=========")
      println("###############################################################################################")
      println()
      println()
    }

    println()
    println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ All Training Finsihed @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

  }

  def loadConfig() = {
    FeatureConfig.loadFeatureConfig("/home/vacml/wlzhao/config/ResourceTables")
    ConfigManager.loadConfigManager("/home/vacml/wlzhao/config/ConfigManager")
    XGBConfig.loadXGBConfig("/home/vacml/wlzhao/config/XGBConfigMap")
  }

  def prepareWideSampleTableDF(): DataFrame = {
    /*imports*/
    import org.apache.spark.sql.types.{DataType, IntegerType, DoubleType}
    import MyExtensions._

    /* Sample Data Time Span */
    val sampleDateSpan = s"d >= '${ConfigManager.conf("startTimeForTrain")}' and d <= '${ConfigManager.conf("endTimeForTest")}'"

    /* Sample Base Table*/
    val rawSampleSPDPDF = MySparkContext.hiveContext.sql("select * from " + FeatureConfig.sampleTableName + " where " + sampleDateSpan).drop("stcityid").drop("channel").drop("date").repartition(ConfigManager.conf("repartitionNum").toInt)
    var rawWideSampleTable = rawSampleSPDPDF.castColumnTo("label", IntegerType)

    /* Convert Feature Matching Tables Index Into Array[String] And Store In FeatureConfig.featureMatchingArrayMap */
    FeatureConfig.featureMatchingTableMap.foreach( table => {
      val tableTagName = table._1
      val featureMatchingTable = table._2
      val tableDF = MySparkContext.hiveContext.sql("select * from " + featureMatchingTable.matchingTableName)
      FeatureConfig.featureMatchingArrayMap(tableTagName) = tableDF.map(row => row.getInt(0).toString).collect()
    })

    /* Combine The Product Single Value Feature Tables */
    FeatureConfig.productSingleValueFeatureTableMap.foreach( table => {
      val featureRename = table._1
      val prod_singleValueFeatureTable = table._2
      var rawSingleValueFeatureDF:DataFrame = null
      if(featureRename == "ClickRatio") { // click ratio table contains "numclick" and "numexpos" other than value column
        rawSingleValueFeatureDF = MySparkContext.hiveContext.sql("select * from " + prod_singleValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").drop("numclick").drop("numexpos").repartition(ConfigManager.conf("repartitionNum").toInt)
      } else {
        rawSingleValueFeatureDF = MySparkContext.hiveContext.sql("select * from " + prod_singleValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      }
      val singleValueFeatureDF = rawSingleValueFeatureDF.castColumnTo(prod_singleValueFeatureTable.featureColName, DoubleType)
      rawWideSampleTable = rawWideSampleTable.prodTableJoin(singleValueFeatureDF, featureRename)
    })

    /* Combine The Product Multi Value Feature Tables */
    FeatureConfig.productMultiValueFeatureTableMap.foreach( table => {
      val prod_multiValueFeatureTable = table._2
      val rawMultiValueFeatureDF = MySparkContext.hiveContext.sql("select * from " + prod_multiValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      val discretizedMultiValueFeatureDF = discretizeMultiValuedFeature(rawMultiValueFeatureDF, FeatureConfig.featureMatchingArrayMap(prod_multiValueFeatureTable.featureMatchingTableTagName), prod_multiValueFeatureTable.featuresRenamePrefix)
      rawWideSampleTable = rawWideSampleTable.prodTableJoin(discretizedMultiValueFeatureDF, "", false)
    })

    /* Combine The User Single Value Feature Tables */
    FeatureConfig.userSingleValueFeatureTableMap.foreach( table => {
      val featureRename = table._1
      val user_singleValueFeatureTable = table._2
      val rawSingleValueFeatureDF = MySparkContext.hiveContext.sql("select * from " + user_singleValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      val singleValueFeatureDF = rawSingleValueFeatureDF.castColumnTo(user_singleValueFeatureTable.featureColName, DoubleType)
      rawWideSampleTable = rawWideSampleTable.userTableJoin(singleValueFeatureDF, featureRename)
    })

    /* Combine The User Multi Value Feature Tables */
    FeatureConfig.userMultiValueFeatureTableMap.foreach( table => {
      val user_multiValueFeatureTable = table._2
      val rawMultiValueFeatureDF = MySparkContext.hiveContext.sql("select * from " + user_multiValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      val discretizedMultiValueFeatureDF = discretizeMultiValuedFeature(rawMultiValueFeatureDF, FeatureConfig.featureMatchingArrayMap(user_multiValueFeatureTable.featureMatchingTableTagName), user_multiValueFeatureTable.featuresRenamePrefix)
      rawWideSampleTable = rawWideSampleTable.userTableJoin(discretizedMultiValueFeatureDF, "", false)
    })

    /*clean useless features from rawWideSampleTable(drop uid, pkgid and d)*/
    val defaultValueForNull = -9999
    val wideSampleTable = rawWideSampleTable.repartition(ConfigManager.conf("repartitionNum").toInt).drop("uid").drop("pkgid")
      .na.fill(defaultValueForNull).filter(s"label != '$defaultValueForNull'") // reduce the rows that does not have valid label value
    wideSampleTable



//    /*Search Current Feature Tables*/
//    // product tables
//    val prod_CommentCount_TableName = "dw_vacmldb.tour_prod_commentcnt"
//    val prod_CommentScore_TableName = "dw_vacmldb.tour_prod_commentscore"
//    val prod_ClickRatio_TableName = "dw_vacmldb.tour_prod_clickratio"
//    val prod_TravelCount_TableName = "dw_vacmldb.tour_prod_travelcnt"
//    val prod_TravelDays_TableName = "dw_vacmldb.tour_prod_traveldays"
//    val prod_SaleMode_TableName = "dw_vacmldb.tour_prod_salemode"
//    val prod_Level_TableName = "dw_vacmldb.tour_prod_level"
//    val prod_Pattern_TableName = "dw_vacmldb.tour_prod_pattern"
//    val prod_HotLine_TableName = "dw_vacmldb.tour_prod_hotline"
//    /*product multi-valued features*/
//    val prod_HotTag_TableName = "dw_vacmldb.tour_prod_hottag"
//    // user tables
//    val user_VIPFlag_TableName = "dw_vacmldb.tour_user_vipflag"
//    val user_Grade_TableName = "dw_vacmldb.tour_user_grade"
//    val user_GenerousHTL_TableName = "dw_vacmldb.tour_user_generous_htl"
//    val user_GenerousFLT_TableName = "dw_vacmldb.tour_user_generous_flt"
//    val user_CustomerValue_TableName = "dw_vacmldb.tour_user_customervalue"
//    val user_CtripProfits_TableName = "dw_vacmldb.tour_user_ctripprofits"
//    val user_Crown_TableName = "dw_vacmldb.tour_user_crown"
//    /* user multi-valued features */
//    val user_PrefPattern_TableName = "dw_vacmldb.tour_user_pref_dp_pattern_td_nomap"
//    val user_PrefLevel_TableName = "dw_vacmldb.tour_user_pref_dp_level_td_nomap"
//    val user_PrefHotLine_TableName = "dw_vacmldb.tour_user_pref_dp_hotline_td_nomap"
//    val user_PrefTravelDays_TableName = "dw_vacmldb.tour_user_pref_dp_traveldays_td_nomap"
//    val user_PrefSaleMode_TabelName = "dw_vacmldb.tour_user_pref_dp_salemode_td_nomap"
//    val user_PrefHotTag_TabelName = "dw_vacmldb.tour_user_pref_dp_hottag_td_nomap"
//    /*sample table */
//    val sample_TableName = "dw_vacmldb.tour_ctr_sample_spdp_nomap"
//    /* multi-value features matching tables */
//    val match_HotLineTour_TabelName = "dw_vacmldb.hotline_tour"
//    val match_HotTagTour_TableName = "dw_vacmldb.hottag_tour"*/
//
//    /*imports*/
//    import org.apache.spark.sql.types.{DataType, IntegerType, DoubleType}
//
//    // get product/user feature tables and convert feature value into Numeric DataType (Integer or Double)
//    val sampleDateSpan = s"d >= '${ConfigManager.conf("startTimeForTrain")}' and d <= '${ConfigManager.conf("endTimeForTest")}'"*/
//    /* product single value features */
//    val rawProdCommentCountDF = MySparkContext.hiveContext.sql("select * from " + prod_CommentCount_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdCommentScoreDF = MySparkContext.hiveContext.sql("select * from " + prod_CommentScore_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdClickRatioDF = MySparkContext.hiveContext.sql("select * from " + prod_ClickRatio_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").drop("numclick").drop("numexpos").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdTravelCountDF = MySparkContext.hiveContext.sql("select * from " + prod_TravelCount_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdTravelDaysDF = MySparkContext.hiveContext.sql("select * from " + prod_TravelDays_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdSaleModeDF = MySparkContext.hiveContext.sql("select * from " + prod_SaleMode_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdLevelDF = MySparkContext.hiveContext.sql("select * from " + prod_Level_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdPatternDF = MySparkContext.hiveContext.sql("select * from " + prod_Pattern_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawProdHotLineDF = MySparkContext.hiveContext.sql("select * from " + prod_HotLine_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt)
//    /*product multi-valued features */
//    val rawProdHotTagDF = MySparkContext.hiveContext.sql("select * from " + prod_HotTag_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt)
//    /*user single value features*/
//    val rawUserVIPFlagDF = MySparkContext.hiveContext.sql("select * from " + user_VIPFlag_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserGradeDF = MySparkContext.hiveContext.sql("select * from " + user_Grade_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserGenerousHTLDF = MySparkContext.hiveContext.sql("select * from " + user_GenerousHTL_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserGenerousFLTDF = MySparkContext.hiveContext.sql("select * from " + user_GenerousFLT_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserCustomerValueDF = MySparkContext.hiveContext.sql("select * from " + user_CustomerValue_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserCtripProfitsDF = MySparkContext.hiveContext.sql("select * from " + user_CtripProfits_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserCrownDF = MySparkContext.hiveContext.sql("select * from " + user_Crown_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    /*user multi-valued features*/
//    val rawUserPrefPatternDF = MySparkContext.hiveContext.sql("select * from " + user_PrefPattern_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserPrefLevelDF = MySparkContext.hiveContext.sql("select * from " + user_PrefLevel_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserPrefHotLineDF = MySparkContext.hiveContext.sql("select * from " + user_PrefHotLine_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserPrefTravelDaysDF = MySparkContext.hiveContext.sql("select * from " + user_PrefTravelDays_TableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserPrefSaleModeDF = MySparkContext.hiveContext.sql("select * from " + user_PrefSaleMode_TabelName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    val rawUserPrefHotTagDF = MySparkContext.hiveContext.sql("select * from " + user_PrefHotTag_TabelName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt);
//    /*sample table*/
//    val rawSampleSPDPDF = MySparkContext.hiveContext.sql("select * from " + sample_TableName + " where " + sampleDateSpan).drop("stcityid").drop("channel").drop("date").repartition(ConfigManager.conf("repartitionNum").toInt);
//    /*multi-value features matching tables*/
//    val matchHotLineTourDF = MySparkContext.hiveContext.sql("select * from " + match_HotLineTour_TabelName)
//    val matchHotTagTourDF = MySparkContext.hiveContext.sql("select * from " + match_HotTagTour_TableName)
//    val matchHotLineArray = matchHotLineTourDF.map(row => row.getInt(0).toString).collect()
//    val matchHotTagArray = matchHotTagTourDF.map(row => row.getInt(0).toString).collect()
//
//    //import MyExtensions._
//    /*convert feature value into Numeric DataType (Integer or Double)*/
//    /*product single value tables*/
//    val prodCommentCountDF = rawProdCommentCountDF.castColumnTo("value", DoubleType) // the columns that are not explicitly commented DoubleType are IntegerType
//    val prodCommentScoreDF = rawProdCommentScoreDF.castColumnTo("value", DoubleType) // this is DoubleType
//    val prodClickRatioDF = rawProdClickRatioDF.castColumnTo("value", DoubleType)  // this is DoubleType
//    val prodTravelCountDF = rawProdTravelCountDF.castColumnTo("value", DoubleType)
//    val prodTravelDaysDF = rawProdTravelDaysDF.castColumnTo("value", DoubleType)
//    val prodSaleModeDF = rawProdSaleModeDF.castColumnTo("value", DoubleType)
//    val prodLevelDF = rawProdLevelDF.castColumnTo("value", DoubleType)
//    val prodPatternDF = rawProdPatternDF.castColumnTo("value", DoubleType)
//    val prodHotLineDF = rawProdHotLineDF.castColumnTo("value", DoubleType)
//    /*product multi-value tables*/
//    val prodHotTagDF = discretizeMultiValuedFeature(rawProdHotTagDF, matchHotTagArray, "p_hottag_")
//    /*user tables*/
//    val userVIPFlagDF = rawUserVIPFlagDF.castColumnTo("value", DoubleType)
//    val userGradeDF = rawUserGradeDF.castColumnTo("value", DoubleType)
//    val userGenerousHTLDF = rawUserGenerousHTLDF.castColumnTo("value", DoubleType)
//    val userGenerousFLTDF = rawUserGenerousFLTDF.castColumnTo("value", DoubleType)
//    val userCustomerValueDF = rawUserCustomerValueDF.castColumnTo("value", DoubleType) // this is double type
//    val userCtripProfitsDF = rawUserCtripProfitsDF.castColumnTo("value", DoubleType)  // this is double type
//    val userCrownDF = rawUserCrownDF.castColumnTo("value", DoubleType)
//    /*user multi-value tables*/
//    val userPrefHotTagDF = discretizeMultiValuedFeature(rawUserPrefHotTagDF, matchHotTagArray, "u_hottag_")*/
//    /*sample base table*/
//    val sampleSPDPDF = rawSampleSPDPDF.castColumnTo("label", IntegerType)
//    /*combine tables and make one wide sample table*/
//    val rawWideSampleTable = sampleSPDPDF.userTableJoin(userVIPFlagDF, "VIPFlag").userTableJoin(userGradeDF, "Grade")
//      .userTableJoin(userGenerousHTLDF, "GenerousHTL").userTableJoin(userGenerousFLTDF, "GenerousFLT")
//      .userTableJoin(userCustomerValueDF, "CustomerValue").userTableJoin(userCtripProfitsDF, "CtripProfits")
//      .userTableJoin(userCrownDF, "Crown").userTableJoin(userPrefHotTagDF, "", false)
//
//      .prodTableJoin(prodCommentCountDF, "CommentCount").prodTableJoin(prodCommentScoreDF, "CommentScore")
//      .prodTableJoin(prodClickRatioDF, "ClickRatio").prodTableJoin(prodTravelCountDF, "TravelCount")
//      .prodTableJoin(prodTravelDaysDF, "TravelDays").prodTableJoin(prodSaleModeDF, "SaleMode")
//      .prodTableJoin(prodLevelDF, "Level").prodTableJoin(prodPatternDF, "Pattern")
//      .prodTableJoin(prodHotLineDF, "HotLine").prodTableJoin(prodHotTagDF, "", false)
//    /*clean useless features from rawWideSampleTable(drop uid, pkgid and d)*/
//    val defaultValueForNull = -9999
//    val wideSampleTable = rawWideSampleTable.repartition(ConfigManager.conf("repartitionNum").toInt).drop("uid").drop("pkgid")
//      .na.fill(defaultValueForNull).filter(s"label != '$defaultValueForNull'") // reduce the rows that does not have valid label value
//    wideSampleTable

  }

  def discretizeMultiValuedFeature(toBeDiscretizedDF:DataFrame, sparseFeaturesID:Array[String], sparseFeaturesPrefix:String):DataFrame = {
    /*Discretize multi-value feature DataFrame into sparse feature RDD*/
    /* toBeDiscretizedDF is like below:
    +--------+--------------+----------+
    |     key|         value|         d|
    +--------+--------------+----------+
    |11700777|         0,2,3|2016-12-22|
    | 8600570|           0,3|2016-12-22|
    +--------+--------------+----------+
     */
    val keyColName = toBeDiscretizedDF.columns(0)
    val dateColName = toBeDiscretizedDF.columns(toBeDiscretizedDF.columns.length - 1)
    val sparsedRDD = toBeDiscretizedDF.map(row => {
      val key = row.getAs[String](0)
      val targetSparseFeatureIDs = row.getAs[String](1).trim // remove the heading and tailing spaces
      val d = row.getAs[String](2)
      val featureIDArray = targetSparseFeatureIDs.split("\\s*,\\s*") // array of sparse feature id

      val sparseFeatureValuesBuf = ArrayBuffer.empty[Any]
      sparseFeatureValuesBuf += key
      for(id <- sparseFeaturesID) {
        sparseFeatureValuesBuf += {if(featureIDArray.contains(id))  1.0 else 0.0}
      }
      sparseFeatureValuesBuf += d
      Row.fromSeq(sparseFeatureValuesBuf)
    })

    /*convert RDD to DataFrame*/
    val structFieldsBuf = ArrayBuffer.empty[StructField]
    structFieldsBuf += StructField(keyColName, StringType, false)
    for(id <- sparseFeaturesID) {
      structFieldsBuf += StructField(sparseFeaturesPrefix + id, DoubleType, false)
    }
    structFieldsBuf += StructField(dateColName, StringType, false)
    val schema = StructType(structFieldsBuf)

    /* return sparsedDF is something like below if sparseFeaturesPrefix = "prefix_" and sparseFeaturesID = Array["0", "1," "2", "3", "4"]:
    +--------+--------+--------+--------+--------+--------+----------+
    |     key|prefix_0|prefix_1|prefix_2|prefix_3|prefix_4|         d|
    +--------+--------+--------+--------+--------+--------+----------+
    |11700777|     1.0|     0.0|     1.0|     1.0|     0.0|2016-12-22|
    | 8600570|     1.0|     0.0|     0.0|     1.0|     0.0|2016-12-22|
     */
    val sparsedDF = MySparkContext.hiveContext.createDataFrame(sparsedRDD, schema)
    sparsedDF
  }

  def VectorizeFeatureColumns(df:DataFrame, labelColName:String, features:Array[String]): DataFrame = {
    // sample table with features turned into one vector
    import org.apache.spark.ml.feature.{VectorAssembler}
    // user feature prefix in combined table
    //val u_ = "u_"
    // product feature prefix in combined table
    //val p_ = "p_"
    //val features = Array(u_ + "VIPFlag", u_ + "Grade", u_ + "GenerousHTL", u_ + "GenerousFLT", u_ + "CustomerValue", u_ + "CtripProfits", u_ + "Crown", p_ + "CommentCount", p_ + "CommentScore", p_ + "ClickRatio", p_ + "TravelCount", p_ + "TravelDays", p_ + "SaleMode", p_ + "Level", p_ + "Pattern");

    val assembler = new VectorAssembler().setInputCols(features).setOutputCol("features")
    // the feature columns vectorized dataframe
    val featureVectorizedDF = assembler.transform(df).select(labelColName, "features")
    featureVectorizedDF
  }

  def splitData(df:DataFrame):(DataFrame, DataFrame) = {
    val startTimeForTrain = ConfigManager.conf("startTimeForTrain")
    val endTimeForTrain = ConfigManager.conf("endTimeForTrain")
    val startTimeForTest = ConfigManager.conf("startTimeForTest")
    val endTimeForTest = ConfigManager.conf("endTimeForTest")
    val dfForTrain = df.repartition(ConfigManager.conf("repartitionNum").toInt).filter(s"d>='$startTimeForTrain' and d<='$endTimeForTrain'")
    val dfForTest = df.repartition(ConfigManager.conf("repartitionNum").toInt).filter(s"d>='$startTimeForTest' and d<='$endTimeForTest'")
    (dfForTrain, dfForTest)
  }

  def sampling(originDF:DataFrame, fraction:Double, seed: Long) = {

    val positive = originDF.filter(s"${ConfigManager.conf("labelColName")} = ${ConfigManager.conf("positiveValue").toInt}")
    val negtive = originDF.filter(s"${ConfigManager.conf("labelColName")} = ${ConfigManager.conf("negtiveValue").toInt}")
    val keptNegtive = negtive.sample(withReplacement = false, fraction, seed)//.repartition(ConfigManager.repartitionNum1)

    val negCount = keptNegtive.count().toDouble
    val posCount = positive.count().toDouble
    val scalePosWeight = negCount/posCount
    println("Negative Sampling Rate: " + fraction)
    println("Negative sample numbers after sampling: " + negCount) // 2839008
    println("Positive sample numbers after sampling: " + posCount) // 1353412
    println("scale_pos_weight should be(num(neg)/num(pos)): " + scalePosWeight + " =========")

    (positive.repartition(ConfigManager.conf("repartitionNum").toInt).unionAll(keptNegtive.repartition(ConfigManager.conf("repartitionNum").toInt)), scalePosWeight)
  }

  def convertToRDDofMLBLabeledPoint(df:DataFrame):RDD[org.apache.spark.mllib.regression.LabeledPoint] = {
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      org.apache.spark.mllib.regression.LabeledPoint(row.getInt(0).toDouble, Vectors.dense(buf.toArray))
    })
    rdd
  }

  def convertToRDDofMLBSparseVecLabeledPoint(df:DataFrame):RDD[org.apache.spark.mllib.regression.LabeledPoint] = {
    val vecSize = df.columns.length - 1
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val nonZeroValuesIndices = ArrayBuffer.empty[Int]
      val valuesBuf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        val value = row.getDouble(i)
        if(value != 0.0) {
          nonZeroValuesIndices += i - 1
          valuesBuf += row.getDouble(i)
        }
      }
      org.apache.spark.mllib.regression.LabeledPoint(row.getInt(0).toDouble, Vectors.sparse(vecSize, nonZeroValuesIndices.toArray, valuesBuf.toArray))
    })
    rdd
  }

  def convertToRDDofDMLCLabeledPoint(df:DataFrame):RDD[ml.dmlc.xgboost4j.LabeledPoint] = {
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      ml.dmlc.xgboost4j.LabeledPoint.fromDenseVector(row.getInt(0).toFloat, buf.toArray.map(_.toFloat))
    })
    rdd
  }

  def convertToRDDofLabeledPoint(rdd:RDD[Row]):RDD[LabeledPoint] = {
    val rddl = rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double];
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      LabeledPoint(row.getInt(0).toDouble, Vectors.dense(buf.toArray));
    })
    rddl
  }

  def dumpModel(model: XGBoostModel) = {
    val strModel = model.booster.getModelDump();
    strModel;
  }

  def saveModel(savePath:String, model:XGBoostModel) = {
    model.saveModelAsHadoopFile(savePath)//(MySparkContext.sc);
  }

  def convert(rdd: RDD[org.apache.spark.mllib.regression.LabeledPoint], isFeatureDenseVector:Boolean = true): RDD[ml.dmlc.xgboost4j.LabeledPoint] = {
    rdd.map(labelPoint => {
      if(isFeatureDenseVector) {
        ml.dmlc.xgboost4j.LabeledPoint.fromDenseVector(labelPoint.label.toFloat, labelPoint.features.toArray.map(_.toFloat))
      }
      else {
        ml.dmlc.xgboost4j.LabeledPoint.fromSparseVector(labelPoint.label.toFloat, labelPoint.features.asInstanceOf[SparseVector].indices, labelPoint.features.asInstanceOf[SparseVector].values.map(_.toFloat))//(labelPoint.label.toFloat, labelPoint.features.toArray.map(_.toFloat))
      }
    })
  }

  // from stackoverflow, alternative method of model predict
  // http://stackoverflow.com/questions/36770190/xgboost-4j-by-dmlc-on-spark-1-6-1
  def labelPredict(testSet: RDD[ml.dmlc.xgboost4j.LabeledPoint], useExternalCache: Boolean = false, _booster: XGBoostModel): RDD[(Double, Double)] = {
    import ml.dmlc.xgboost4j.scala.spark.{DataUtils}
    val booster = _booster.asInstanceOf[XGBoostModel].booster
    val broadcastBooster = testSet.sparkContext.broadcast(booster)
    testSet.mapPartitions { testData =>
      val (auxiliaryIterator, testDataIterator) = testData.duplicate
      val testDataArray = auxiliaryIterator.toArray
      val prediction = broadcastBooster.value.predict(new ml.dmlc.xgboost4j.scala.DMatrix(testDataIterator)).flatten
      testDataArray
        .zip(prediction)
        .map {
          case (labeledPoint, predictionValue) =>
            (predictionValue.toDouble, labeledPoint.label.toDouble)
        }.toIterator
    }
  }

  def auc(predictionAndLabels:RDD[(Double,Double)]) = {
    val metrics = new BinaryClassificationMetrics(predictionAndLabels)
    val aucResult = metrics.areaUnderROC
    aucResult
  }
}


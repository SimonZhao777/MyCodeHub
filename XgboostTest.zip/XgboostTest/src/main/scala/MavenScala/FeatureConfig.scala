package MavenScala

import scala.xml.XML

/**
  * Created by zhaowl on 2017/1/17.
  */
object FeatureConfig {
  var sampleTableName:String = null
  val featureMatchingTableMap = scala.collection.mutable.Map[String, FeatureMatchingTable]()
  val featureMatchingArrayMap = scala.collection.mutable.Map[String, Array[String]]()
  val productSingleValueFeatureTableMap = scala.collection.mutable.Map[String, ProdSingleValueFeatureTable]()
  val productMultiValueFeatureTableMap = scala.collection.mutable.Map[String, ProdMultiValueFeatureTable]()
  val userSingleValueFeatureTableMap = scala.collection.mutable.Map[String, UserSingleValueFeatureTable]()
  val userMultiValueFeatureTableMap = scala.collection.mutable.Map[String, UserMultiValueFeatureTable]()

  def loadFeatureConfig(path:String): Unit = {
    /* Feature Configurations */
    val featureConfig = XML.loadFile(path)
    featureConfig.foreach(rootNode => {
      val sampleTable = rootNode\\"FeatureTables"\\"SampleTable"
      val featureMatchingTables = rootNode\\"FeatureTables"\\"FeatureMachingTables"\\"MatchingTable"
      val prod_singleValueFeatureTables = rootNode\\"FeatureTables"\\"ProductFeatureTables"\\"SingleValueFeatureTables"\\"SingleValueFeatureTable"
      val prod_multiValueFeatureTables = rootNode\\"FeatureTables"\\"ProductFeatureTables"\\"MultiValueFeatureTables"\\"MultiValueFeatureTable"
      val user_singleValueFeatureTables = rootNode\\"FeatureTables"\\"UserFeatureTables"\\"SingleValueFeatureTables"\\"SingleValueFeatureTable"
      val user_multiValueFeatureTables = rootNode\\"FeatureTables"\\"UserFeatureTables"\\"MultiValueFeatureTables"\\"MultiValueFeatureTable"

      /* Sample Table */
      sampleTableName = sampleTable.text

      /* Feature Matching Tables */
      featureMatchingTables.foreach(targetNode => {
        val tableTagName = (targetNode\\"@tableTagName").text
        val tableName = targetNode.text
        FeatureConfig.featureMatchingTableMap(tableTagName)
          = new FeatureMatchingTable(tableTagName, tableName)
      })

      /* Product Feature Tables */
      /* Single Value */
      prod_singleValueFeatureTables.foreach(targetNode => {
        val featureColName = (targetNode\\"@featureColName").text
        val featureRename = (targetNode\\"@featureRename").text
        val featureTableName = targetNode.text
        FeatureConfig.productSingleValueFeatureTableMap(featureRename)
          = new ProdSingleValueFeatureTable(featureColName, featureRename, featureTableName)
      })
      /* Multi Value */
      prod_multiValueFeatureTables.foreach(targetNode => {
        val featureMatchingTableTagName = (targetNode\\"@featureMatchingTableTagName").text
        val featuresRenamePrefix = (targetNode\\"@featuresRenamePrefix").text
        val featureTableName = targetNode.text
        FeatureConfig.productMultiValueFeatureTableMap(featuresRenamePrefix)
          = new ProdMultiValueFeatureTable(featureMatchingTableTagName, featuresRenamePrefix, featureTableName)
      })

      /* User Feature Tables */
      /* Single Value */
      user_singleValueFeatureTables.foreach(targetNode => {
        val featureColName = (targetNode\\"@featureColName").text
        val featureRename = (targetNode\\"@featureRename").text
        val featureTableName = targetNode.text
        FeatureConfig.userSingleValueFeatureTableMap(featureRename)
          = new UserSingleValueFeatureTable(featureColName, featureRename, featureTableName)
      })
      /* Multi Value */
      user_multiValueFeatureTables.foreach(targetNode => {
        val featureMatchingTableTagName = (targetNode\\"@featureMatchingTableTagName").text
        val featuresRenamePrefix = (targetNode\\"@featuresRenamePrefix").text
        val featureTableName = targetNode.text
        FeatureConfig.userMultiValueFeatureTableMap(featuresRenamePrefix)
          = new UserMultiValueFeatureTable(featureMatchingTableTagName, featuresRenamePrefix, featureTableName)
      })
    })
  }
}

class ProdSingleValueFeatureTable(prod_featureColName:String, prod_featureRename:String, prod_featureTableName:String) {
  val featureColName = prod_featureColName
  val featureRename = prod_featureRename
  val featureTableName = prod_featureTableName
}

class ProdMultiValueFeatureTable(prod_featureMatchingTableTagName:String, prod_featuresRenamePrefix:String, prod_featureTableName:String) {
  val featureMatchingTableTagName = prod_featureMatchingTableTagName
  val featuresRenamePrefix = prod_featuresRenamePrefix
  val featureTableName = prod_featureTableName
}

class UserSingleValueFeatureTable(user_featureColName:String, user_featureRename:String, user_featureTableName:String) {
  val featureColName = user_featureColName
  val featureRename = user_featureRename
  val featureTableName = user_featureTableName
}

class UserMultiValueFeatureTable(user_featureMatchingTableTagName:String, user_featuresRenamePrefix:String, user_featureTableName:String) {
  val featureMatchingTableTagName = user_featureMatchingTableTagName
  val featuresRenamePrefix = user_featuresRenamePrefix
  val featureTableName = user_featureTableName
}

class FeatureMatchingTable(tableTagName:String, featureMatchingTableName:String) {
  val matchingTableTagName = tableTagName
  val matchingTableName = featureMatchingTableName
}

package MavenScala

//import ml.dmlc.xgboost4j.LabeledPoint
import java.io.{File, PrintWriter}
import java.util

import ml.dmlc.xgboost4j.java.Rabit
import ml.dmlc.xgboost4j.scala.DMatrix
import ml.dmlc.xgboost4j.scala.spark.{XGBoost, XGBoostModel}
import org.apache.spark.TaskContext
import org.apache.spark.mllib.linalg.SparseVector
import org.apache.spark.sql.types.DataTypes

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.xml.XML
//import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.ml.feature.VectorAssembler

import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint

import scala.collection.mutable.ArrayBuffer
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}



/**
 * A Main to run Camel with MyRouteBuilder
 */
object MyRouteMain /*extends RouteBuilderSupport*/ {

  def main(args: Array[String]) {

    /* Load configurations(DataTables, ConfigManager, XGBConfigMap) from files */
    println("\n\n========= Loading Configuration File Start =========")
    TimeMeter.restart()
    loadConfig()
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Loading Configuration File Ended =========")

    println("\n\n========= Print Config Manager Start =========")
    TimeMeter.restart()
    ConfigManager.conf.foreach(println)
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Print Config Manager Ended =========")

    // prepare sample data
    var rawSampleTableDF:DataFrame = null
    if(ConfigManager.conf("loadDataFromSavedCombinedWideTable") == "true") {
      println("\n\n========= Load Sample Data From Saved Start =========")
      TimeMeter.restart()
      rawSampleTableDF = MySparkContext.hiveContext.read.load(ConfigManager.conf("saveDFPath"))
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Load Sample Data From Saved Ended =========")
    } else {
      println("\n\n========= Load Sample Data From Combining Tables Start =========")
      TimeMeter.restart()
      val discretizeFeatures = if(ConfigManager.conf("discretizeFeaturesByBins") == "true") true else false
      rawSampleTableDF = prepareWideSampleTableDF(discretizeFeatures).repartition(ConfigManager.conf("repartitionNum1").toInt)
      rawSampleTableDF.show()
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Load Sample Data From Combining Tables Ended =========")


      println("\n\n========= Save Combined Sample Data Start =========")
      TimeMeter.restart()
      rawSampleTableDF.write.mode("overwrite").save(ConfigManager.conf("saveDFPath"))
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Save Combined Sample Data Start =========")
    }

    // split data into training and testing according to date(usually 7days training and last day for testing)
    println("\n\n========= Split Data Into Training And Teting By Date Start =========")
    TimeMeter.restart()
    val dataSplitTp = splitData(rawSampleTableDF)
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Split Data Into Training And Teting By Date End =========")

    // sampling the negative samples to balance the positive and negative samples
    println("\n\n========= Sampling Data Start =========")
    TimeMeter.restart()
    val afterSamplingTp2 = sampling(dataSplitTp._1.drop("d"), ConfigManager.conf("underSampleRate").toDouble, 11L)
    val scale_pos_weight = afterSamplingTp2._2
    println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= Sampling Data Ended =========")

    println("\n\n========= start to convert training samples to rddTrain =========")
    TimeMeter.restart()
    /*val rddTrain = convertToRDDofMLBLabeledPoint(afterSamplingTp2._1)*/
    val rddTrain = convertToRDDofMLBSparseVecLabeledPoint(afterSamplingTp2._1)
    println(" SparsedVec LabeledPoint Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    rddTrain.take(20).foreach(println)
    TimeMeter.restart()
    //MySparkContext.hiveContext.createDataFrame(rddTrain).show()
    val rddTrainForPrediction = convert(rddTrain, true)
    println(" LabeledPoint Type Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= rddTrain converting finished finished =========")

    // convert testing DataFrame into RDD[LabeledPoint]
    println("\n\n========= Start to convert testing samples to testingRDDOfLabeledPoint=========")
    TimeMeter.restart()
    /*val rddTest = convertToRDDofMLBLabeledPoint(dataSplitTp._2.drop("d"))*/
    val rddTest = convertToRDDofMLBSparseVecLabeledPoint(dataSplitTp._2.drop("d"))
    println(" SparsedVec LabeledPoint Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    TimeMeter.restart()
    val rddTestForPrediction = convert(rddTest, true)
    //val rddTestForPrediction = convertToRDDofDMLCLabeledPoint(dataSplitTp._2.drop("d"))
    println(" LabeledPoint Type Conversion Time Spent: " + TimeMeter.stop() + " milliseconds")
    println("========= testingRDDOfLabeledPoint converting finished =========")


    // Xgboost model parameters
    /*Handle Imbalanced Dataset
    For common cases such as ads clickthrough log, the dataset is extremely imbalanced.
    This can affect the training of xgboost model, and there are two ways to improve it.

    If you care only about the ranking order (AUC) of your prediction
      Balance the positive and negative weights, via scale_pos_weight
      Use AUC for evaluation
    If you care about predicting the right probability
      In such a case, you cannot re-balance the dataset
    In such a case, set parameter max_delta_step to a finite number (say 1) will help convergence*/
    println("\n\n========= XGBoost Initial Parameter Map Start =========")
    var configMap = List(
      "silent" -> XGBConfig.confMap("silent").toInt,
      "eta" -> XGBConfig.confMap("eta").toDouble, // this is learning rate, normally it should be between 0.05~0.3 or typical value 0.01~0.2, this parameters should be paired with number of trees(nRounds)
      "max_depth" -> XGBConfig.confMap("max_depth").toInt, // typical value 3~10
      "objective" -> XGBConfig.confMap("objective"),
      "gamma" -> XGBConfig.confMap("gamma").toInt,
      "min_child_weight" -> XGBConfig.confMap("min_child_weight").toInt,
      "scale_pos_weight" -> scale_pos_weight, // controls the imbalanced pos and neg samples, usually sum(negative cases) / sum(positive cases), defualt is 1
      "max_delta_step" -> XGBConfig.confMap("max_delta_step").toInt,
      "subsample" -> XGBConfig.confMap("subsample").toDouble, // typical 0.5~1
      "colsample_bytree" -> XGBConfig.confMap("colsample_bytree").toDouble, // typical 0.5~1
      "eval_metric" -> XGBConfig.confMap("eval_metric")).toMap
    var round:Int = XGBConfig.confMap("round").toInt // should be considered with learning rate together(eta), the bigger the learning rate the smaller the round should be.
    val nWorkers:Int = ConfigManager.conf("numWorker").toInt // should set to number of partitions from config file, default is 0 which means the number of partitions will be taken as number of workers
    configMap.foreach(println)
    println("round: " + round)
    println("nWorkers: " + nWorkers)
    println("========= XGBoost Initial Parameter Map Ended =========")

    var modifiedParamName = "round"
    var allRoundIterated = false
    //var bestResult = (Map[String, Any], Integer, String, Boolean)
    while (!allRoundIterated) {
      // train model
      /**
        * train XGBoost model with the RDD-represented data
        * @param trainingData the trainingset represented as RDD
        * @param params Map containing the configuration entries
        * @param round the number of iterations
        * @param nWorkers the number of xgboost workers, 0 by default which means that the number of
        *                 workers equals to the partition number of trainingData RDD
        * @param obj the user-defined objective function, null by default
        * @param eval the user-defined evaluation function, null by default
        * @param useExternalMemory indicate whether to use external memory cache, by setting this flag as
        *                           true, the user may save the RAM cost for running XGBoost within Spark
        * @param missing the value represented the missing value in the dataset
        * @throws ml.dmlc.xgboost4j.java.XGBoostError when the model training is failed
        * @return XGBoostModel when successful training
        */
      println("\n\n========= XGBoost Training Start =========")
      TimeMeter.restart()
      val xgBoostModel = XGBoost.train(rddTrain.repartition(ConfigManager.conf("repartitionNum").toInt), configMap, round, nWorkers, null, null, false/*, Float.NaN*/)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= XGBoost Training Ended =========")

      /*println("========= Load XGBoost Model Start =========")
      val xgBoostModel = XGBoost.loadModelFromHadoopFile(ConfigManager.conf("saveModelPath"))(MySparkContext.sc)
      println("========= Load XGBoost Model Ended =========")*/

      println("\n\n========= Feature Score Start =========")
      TimeMeter.restart()
      val featureScoreMap = xgBoostModel.booster.getFeatureScore()
      val sortedScoreMap = featureScoreMap.toSeq.sortBy(_._2) // ascending order
      val colNames = afterSamplingTp2._1.columns
      var i = sortedScoreMap.size
      for(fs <- sortedScoreMap) {
        val key = fs._1
        val score = fs._2
        val fid = key.substring(1).toInt
        println(key + "(" + colNames(fid +1) + ")" + ":" + score.toString + "   " + i)
        i -= 1
      }
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= Feature Score Ended =========")


      // save model
      println("\n\n========= SaveModel(" + ConfigManager.conf("saveModelPath") + ", xgBoostModel) Start =========")
      TimeMeter.restart()
      // save model to model path
      val file = new File("./model")
      if (!file.exists()) {
        file.mkdirs()
      }
      xgBoostModel.booster.saveModel(file.getAbsolutePath + "/xgb.model")
      saveModel(ConfigManager.conf("saveModelPath"), xgBoostModel)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= SaveModel(" + ConfigManager.conf("saveModelPath") + ", xgBoostModel) Ended =========")

      // dump model
      println("\n\n========= DumpModel(xgBoostModel) Start =========")
      TimeMeter.restart()
      val featureNames = {
        val fNames = new Array[String](colNames.length - 1)
        for( i <- 1 until colNames.length) {
          fNames(i-1) = colNames(i)
        }
        fNames
      }
      createFeatureMap(file.getAbsolutePath + "/xgb.fmap", featureNames)
      val modelInfos = xgBoostModel.booster.getModelDump(file.getAbsolutePath + "/xgb.fmap", withStats = true)
      saveDumpModel(file.getAbsolutePath + "/dump.round" + round + ".txt", modelInfos)
      //val strModel = dumpModel(xgBoostModel)
      println("        Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= DumpModel Ended =========")

      // predict training data auc
      println("\n\n========= Start to predict TRAINING data=========")
      TimeMeter.restart()
      val zipFileTrain = labelPredict(rddTrainForPrediction, false, xgBoostModel)
      println(" Label Predict Time Spent: " + TimeMeter.stop() + " milliseconds")
      TimeMeter.restart()
      val trainDataAUC = auc(zipFileTrain)
      println(" AUC Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= TRAIN data auc by labelPredict: " + trainDataAUC + "=========")

      // predict test data auc
      println("\n\n========= Start to predict TEST data=========")
      TimeMeter.restart()
      val zipFileTest = labelPredict(rddTestForPrediction, false, xgBoostModel)
      println(" Label Predict Time Spent: " + TimeMeter.stop() + " milliseconds")
      TimeMeter.restart()
      val testDataAUC = auc(zipFileTest)
      println(" AUC Time Spent: " + TimeMeter.stop() + " milliseconds")
      println("========= TEST data auc by labelPredict: " + testDataAUC + "=========")

      // update grid search paramMap
      XGBoostParamGen.updateXGBParams(testDataAUC, modifiedParamName, round, configMap)

      println("\n\n========= XGBoost Parameter Map Loop Start =========")
      configMap.foreach(println)
      println("round: " + round)
      println("Train AUC: (" + trainDataAUC + ") Test AUC: (" + testDataAUC + ")")
      println()
      XGBoostParamGen.gridSearchParamsMap.foreach(println)
      println("========= XGBoost Parameter Map Loop Ended =========")

      // get new parameters for next training iteration
      val newXGBParamsResult = XGBoostParamGen.getGridSearchUpdatedXGBParams(configMap, round, "eta")
      configMap = newXGBParamsResult._1
      round = newXGBParamsResult._2
      modifiedParamName = newXGBParamsResult._3
      allRoundIterated = newXGBParamsResult._4

      if(ConfigManager.conf("gridSearchParametersTuning") == "true") {
        allRoundIterated = false
      } else {
        allRoundIterated = true
      }

      println("\n\n=========model over=========")
      println("###############################################################################################")
      println()
      println()
    }

    println()
    println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ All Training Finsihed @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

  }

  def loadConfig() = {
    FeatureConfig.loadFeatureConfig("/home/vacml/wlzhao/cvrXGBoostTest/config/ResourceTables")
    ConfigManager.loadConfigManager("/home/vacml/wlzhao/cvrXGBoostTest/config/ConfigManager")
    XGBConfig.loadXGBConfig("/home/vacml/wlzhao/cvrXGBoostTest/config/XGBConfigMap")
  }

  /* Double value parser */
  def parseDouble(s: String) = {
    try { Some(s.toDouble) } catch { case _ => None }
  }

  // keyName: pid means product id, uid means user id
  def getCombFeaturesDF(keyRename:String, dateRename:String, featureSource: mutable.Map[String, SingleValueFeatureTable], discretizeByBin:Boolean = false): DataFrame = {
    import org.apache.spark.sql.types.{DataType, IntegerType, DoubleType}
    import MyExtensions._

    /* Sample Data Time Span */
    val sampleDateSpan = s"d >= '${ConfigManager.conf("startTimeForTrain")}' and d <= '${ConfigManager.conf("endTimeForTest")}'"

    // 用MapReduce合并所有用户/产品单特征表
    // featureBinMap structure is Map[FeatureRename, Map[discretizeFeatureName, (lowerBound, upperBound)]
    val allFeaturesBinMap = scala.collection.mutable.Map[String, scala.collection.mutable.Map[String, (Double, Double)]]()
    val featuresListBuf = ListBuffer[String]()
    var dfList = ListBuffer[DataFrame]()
    featureSource.foreach( table => {
      val featureRename = table._1
      val prod_singleValueFeatureTable = table._2
      val rawSingleValueFeatureDF = MySparkContext.hiveContext.sql(s"select key, CONCAT('$featureRename', ':', value) as value, d from " + prod_singleValueFeatureTable.featureTableName + " where " + sampleDateSpan).repartition(ConfigManager.conf("repartitionNum").toInt)

      // prepare feature names(discretized/not discretized)
      if(discretizeByBin && prod_singleValueFeatureTable.featureBinConfigTableTagName.nonEmpty) {
        val binArray = FeatureConfig.featureBinConfigArrayMap(prod_singleValueFeatureTable.featureBinConfigTableTagName)
        val singleFeatureBinMap = scala.collection.mutable.Map[String, (Double, Double)]()
        for(bin <- binArray) {
          val discretizedFeatureName = featureRename + bin._1.toString.replace(".", "_") + "~" + bin._2.toString.replace('.', '_')
          featuresListBuf += discretizedFeatureName
          singleFeatureBinMap(discretizedFeatureName) = bin
        }
        allFeaturesBinMap(featureRename) = singleFeatureBinMap
      } else {
        featuresListBuf += featureRename
      }

      dfList += rawSingleValueFeatureDF
    })
    val featureNameList = featuresListBuf.toList

    // 对所有 DataFrame 进行合并, 并通过 reduceByKey 转为 (K,V) 型的 RDD
    val featureSpliter = "#"      // 特征分隔符，同一 key 的多个 value 用 "#" 分割 （因为特征支持多命中，多个取值也是用","分割的，换成"#"）
    val featureValuleSpliter = ":"  // 特征与特征取值分隔符
    val unionDf = dfList.toSeq.reduce(_ unionAll _)
    //println("unionDf:")
    //unionDf.show(100)
    //dfList.clear() // 及时清理为下一天做准备
    val unionRdd = unionDf.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map{
      row => {
        val key   = row.getAs[String]("key") + featureValuleSpliter + row.getAs[String]("d")
        val value = row.getAs[String]("value")
        (key, value)
      }
    }
    //println("unionRdd:")
    //unionRdd.take(100).foreach(println)


    // 按照 unionRdd 的键值进行 reduce
    val groupRdd = unionRdd.repartition(ConfigManager.conf("repartitionNum").toInt).reduceByKey(_ + featureSpliter + _)
    //println("groupdRdd(after reduceByKey):")
    //groupRdd.take(100).foreach(println)

    // 通过解析 groupRdd, 生成一个新的 mapRdd
    val mapRdd = groupRdd.repartition(ConfigManager.conf("repartitionNum").toInt).map {
      row => {
        val uidAndDate = row._1       // uid and date
        val uidAndDateArray = uidAndDate.split(featureValuleSpliter)
        val uid = uidAndDateArray(0).trim()
        val d = uidAndDateArray(1).trim()
        val features = row._2  // all features k1:v1#k2:v2#k3:v3...

        val feature2val = new mutable.HashMap[String, Double]
        for(str <-  featureNameList) {
          feature2val(str) = -9999.99 // 初始化
        }

        val featureArray = features.split(featureSpliter)
        for (featureValuePair <- featureArray) {
          val fvArray = featureValuePair.split(featureValuleSpliter)
          if(fvArray.length==2) {
            val featureRename = fvArray(0).trim()
            val trimedValue = parseDouble(fvArray(1).trim())

            if(discretizeByBin && allFeaturesBinMap.contains(featureRename) && trimedValue.nonEmpty) {
              val currentFeatureBinMap = allFeaturesBinMap(featureRename)
              for(bin <- currentFeatureBinMap) {
                val discretizedFeatureName = bin._1
                val binBound = bin._2
                if(binBound._1 < trimedValue.get && trimedValue.get <= binBound._2) {
                  feature2val(discretizedFeatureName) = 1.0
                } else {
                  feature2val(discretizedFeatureName) = 0.0
                }
              }
            } else {
              if(featureNameList.contains(featureRename) && trimedValue.nonEmpty) {
                feature2val(featureRename) = trimedValue.get
              }
            }
          }
        }

        val fieldValueListBuf = new ListBuffer[Any]()
        fieldValueListBuf += uid
        for (str <- featureNameList) {
          fieldValueListBuf += feature2val(str)
        }
        fieldValueListBuf += d

        val fieldValueList = fieldValueListBuf.toList
        Row.fromSeq(fieldValueList)
      }
    }

    // 构造StructType，为下一步将RDD转为DataFrame做准备
    //val fieldNameList = keyName :: featuresList ::: List(dateName)
    val fields = new util.ArrayList[StructField]()
    fields.add(DataTypes.createStructField(keyRename, DataTypes.StringType, false))
    for (fieldName <- featureNameList) {
      fields.add(DataTypes.createStructField(fieldName, DataTypes.DoubleType, false))
    }
    fields.add(DataTypes.createStructField(dateRename, DataTypes.StringType, false))
    val structType = DataTypes.createStructType(fields)

    // 将RDD转为DataFrame
    val featuresDF = MySparkContext.hiveContext.createDataFrame(mapRdd, structType)
    featuresDF
  }

  def prepareWideSampleTableDF(discretizeFeaturesByBins:Boolean): DataFrame = {

    // 训练数据时间分区
    val d = "2017-04-12"
    /* Sample Data Time Span */
    val sampleDateSpan = s"d >= '${ConfigManager.conf("startTimeForTrain")}' and d <= '${ConfigManager.conf("endTimeForTest")}'"

    /* Sample Base Table*/
    /* my sample table */
    var rawSampleSPDPDF = MySparkContext.hiveContext.sql("select label, uid, pkgid, date, d from " + FeatureConfig.sampleTableName + " where d='" + d + "' and date>='" + ConfigManager.conf("startTimeForTrain") + "'" + " and date<='" + ConfigManager.conf("endTimeForTest") + "'").drop("d").withColumnRenamed("date", "d").repartition(ConfigManager.conf("repartitionNum").toInt)


    /* ZY's sample table */
    //var rawSampleSPDPDF = MySparkContext.hiveContext.sql("select case when label='2' then '1' when label='1' then '0' end as label, uid, pkgid, d from dw_vacmldb.tour_cvr_example_01 where d>='" + ConfigManager.conf("startTimeForTrain") + "'" + " and d<='" + ConfigManager.conf("endTimeForTest") + "'" + " and (label='1' or label='2')").repartition(ConfigManager.conf("repartitionNum").toInt)




    /* Combine The User Single Value Feature Tables */
    val userFeaturesDF = getCombFeaturesDF("f_uid", "u_d", FeatureConfig.userSingleValueFeatureTableMap, discretizeFeaturesByBins)

    /* Combine The Product Single Value Feature Tables */
    val prodFeaturesDF = getCombFeaturesDF("f_pid", "p_d", FeatureConfig.productSingleValueFeatureTableMap, discretizeFeaturesByBins)
    prodFeaturesDF.show(100)

    import MyExtensions.RichDataFrame

    /* Discretized Product Features */
    /*FeatureConfig.productSingleValueFeatureTableMap.foreach( table => {
      val prod_singleValueFeatureTable = table._2
      val rawSingleValueFeatureDF = MySparkContext.hiveContext.sql("select key, value, d from " + prod_singleValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "p_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      val discretizedSingleValueFeatureDF = discretizingContinuousFeature(rawSingleValueFeatureDF, , prod_singleValueFeatureTable.featureRename)
      rawSampleSPDPDF = rawSampleSPDPDF.prodTableJoin(discretizedSingleValueFeatureDF, "", false)
    })*/


    /* YJ's product table */
    /*val YJProdFeatureDF = MySparkContext.hiveContext.sql("select pkgid as f_pid, d as p_d, case when (trim(prod_advancebookingdays)='null' or prod_advancebookingdays is null or trim(prod_advancebookingdays)='') then '-9999.99' else prod_advancebookingdays end as prod_advancebookingdays, case when prod_isweekendwork='T' then '1' when prod_isweekendwork='F' then '0' else '-9999.99' end as prod_isweekendwork, case when prod_isholidaywork='T' then '1' when prod_isholidaywork='F' then '0' else '-9999.99' end as prod_isholidaywork, case when (trim(prod_salecity_number)='null' or prod_salecity_number is null or trim(prod_salecity_number)='') then '-9999.99' else prod_salecity_number end as prod_salecity_number, case when (trim(prod_startcity_number)='null' or trim(prod_startcity_number)='' or prod_startcity_number is null) then '-9999.99' else prod_startcity_number end as prod_startcity_number from tmp_vacmldb.tour_prod_yjlin")
    val YJProdCastedFeatureDF = YJProdFeatureDF.withColumn("prod_advancebookingdays", YJProdFeatureDF("prod_advancebookingdays").cast(DoubleType)).withColumn("prod_isweekendwork", YJProdFeatureDF("prod_isweekendwork").cast(DoubleType)).withColumn("prod_isholidaywork", YJProdFeatureDF("prod_isholidaywork").cast(DoubleType)).withColumn("prod_salecity_number", YJProdFeatureDF("prod_salecity_number").cast(DoubleType)).withColumn("prod_startcity_number", YJProdFeatureDF("prod_startcity_number").cast(DoubleType))
    rawSampleSPDPDF = rawSampleSPDPDF.join(YJProdCastedFeatureDF, (rawSampleSPDPDF("pkgid") === YJProdCastedFeatureDF("f_pid")) && (rawSampleSPDPDF("d") === YJProdCastedFeatureDF("p_d")) , "left").drop("f_pid").drop("p_d")*/


    /* 将featuresDF特征表与sample表合并 */

    val defaultValueForNull = -9999.99
    rawSampleSPDPDF = rawSampleSPDPDF.join(userFeaturesDF, (rawSampleSPDPDF("uid") === userFeaturesDF("f_uid")) && (rawSampleSPDPDF("d") === userFeaturesDF("u_d")) , "left").drop("f_uid").drop("u_d")
    rawSampleSPDPDF = rawSampleSPDPDF.join(prodFeaturesDF, (rawSampleSPDPDF("pkgid") === prodFeaturesDF("f_pid")) && (rawSampleSPDPDF("d") === prodFeaturesDF("p_d")) , "left").drop("f_pid").drop("p_d")

    /* Combine The User Multi Value Feature Tables */
    FeatureConfig.userMultiValueFeatureTableMap.foreach( table => {
      val user_multiValueFeatureTable = table._2
      val rawMultiValueFeatureDF = MySparkContext.hiveContext.sql("select key, value, d from " + user_multiValueFeatureTable.featureTableName + " where " + sampleDateSpan).withColumnRenamed("d", "u_d").repartition(ConfigManager.conf("repartitionNum").toInt)
      val ontHotEncodedMultiValueFeatureDF = oneHotEncodingMultiValuedFeature(rawMultiValueFeatureDF, FeatureConfig.featureMatchingArrayMap(user_multiValueFeatureTable.featureMatchingTableTagName), user_multiValueFeatureTable.featuresRenamePrefix)
      rawSampleSPDPDF = rawSampleSPDPDF.userTableJoin(ontHotEncodedMultiValueFeatureDF, "", false)
    })

    rawSampleSPDPDF.drop("uid").drop("pkgid").castColumnTo("label", IntegerType).na.fill(defaultValueForNull).filter(s"label != '$defaultValueForNull'") // label, d, features*,  d was kept for later data split
  }

  /* Discretizing continous feature DataFrame into sparse feature DataFrame
  discretizedFeaturesNames is in this format(a~b]:
  0.0~0.03
  0.03~0.05
  0.05~0.08
  ...
  */
  def discretizingContinuousFeature(toBeDiscretizedDF:DataFrame, binBoundaries:Array[(Double, Double)], sparseFeaturesPrefix:String):DataFrame = {
    /* toBeDiscretizedDF is like below:
    +--------+--------------+----------+
    |     key|         value|         d|
    +--------+--------------+----------+
    |11700777|         13.51|2016-12-22|
    | 8600570|         52.97|2016-12-22|
    +--------+--------------+----------+
    */
    /*One hot encoding multi-value feature DataFrame into sparse feature RDD*/
    val keyColName = toBeDiscretizedDF.columns(0)
    val dateColName = toBeDiscretizedDF.columns(toBeDiscretizedDF.columns.length - 1)

    val sparsedRDD = toBeDiscretizedDF.map(row => {
      val key = row.getAs[String](0)
      val value = row.getAs[String](1).trim // remove the heading and tailing spaces
      val d = row.getAs[String](2)

      val continuousValue = parseDouble(value)

      val sparseFeatureValuesBuf = ArrayBuffer.empty[Any]
      sparseFeatureValuesBuf += key
      for(binBoundary <- binBoundaries) {
        sparseFeatureValuesBuf += {
          if(continuousValue.isEmpty) { // if the continuous value can not be parsed as double type value then the bin value should be -9999.99
            -9999.99
          } else {
            if(binBoundary._1 < continuousValue.get && continuousValue.get <= binBoundary._2)  1.0 else 0.0}
          }
      }
      sparseFeatureValuesBuf += d
      Row.fromSeq(sparseFeatureValuesBuf)
    })

    /*convert RDD to DataFrame*/
    val structFieldsBuf = ArrayBuffer.empty[StructField]
    structFieldsBuf += StructField(keyColName, StringType, false)
    for(binBoundary <- binBoundaries) {
      structFieldsBuf += StructField(sparseFeaturesPrefix +"(" + binBoundary._1.toString + "~" + binBoundary._2.toString + "]", DoubleType, false)
    }
    structFieldsBuf += StructField(dateColName, StringType, false)
    val schema = StructType(structFieldsBuf)

    /* return sparsedDF is something like below if sparseFeaturesPrefix = "prefix_" and sparseFeaturesID = Array["0", "1," "2", "3", "4"]:
    +--------+--------+--------+--------+--------+--------+----------+
    |     key|prefix_0|prefix_1|prefix_2|prefix_3|prefix_4|         d|
    +--------+--------+--------+--------+--------+--------+----------+
    |11700777|     1.0|     0.0|     1.0|     1.0|     0.0|2016-12-22|
    | 8600570|     1.0|     0.0|     0.0|     1.0|     0.0|2016-12-22|
    */
    val discretizedDF = MySparkContext.hiveContext.createDataFrame(sparsedRDD, schema)
    discretizedDF
  }

  /* One hot encoding multi-value feature DataFrame into sparse feature DataFrame */
  def oneHotEncodingMultiValuedFeature(toBeOneHotEncodedDF:DataFrame, sparseFeaturesID:Array[String], sparseFeaturesPrefix:String):DataFrame = {
    /* toBeOneHotEncodedDF is like below:
    +--------+--------------+----------+
    |     key|         value|         d|
    +--------+--------------+----------+
    |11700777|         0,2,3|2016-12-22|
    | 8600570|           0,3|2016-12-22|
    +--------+--------------+----------+
    */
    /*One hot encoding multi-value feature DataFrame into sparse feature RDD*/
    val keyColName = toBeOneHotEncodedDF.columns(0)
    val dateColName = toBeOneHotEncodedDF.columns(toBeOneHotEncodedDF.columns.length - 1)
    val sparsedRDD = toBeOneHotEncodedDF.map(row => {
      val key = row.getAs[String](0)
      val targetSparseFeatureIDs = row.getAs[String](1).trim // remove the heading and tailing spaces
      val d = row.getAs[String](2)
      val featureIDArray = targetSparseFeatureIDs.split("\\s*,\\s*") // array of sparse feature id, regex "\\s*,\\s*" means comma with any number of preceded and tailed white spaces, so that splitted feature IDs could only be numbers without spaces.

      val sparseFeatureValuesBuf = ArrayBuffer.empty[Any]
      sparseFeatureValuesBuf += key
      for(id <- sparseFeaturesID) {
        sparseFeatureValuesBuf += {if(featureIDArray.contains(id))  1.0 else 0.0}
      }
      sparseFeatureValuesBuf += d
      Row.fromSeq(sparseFeatureValuesBuf)
    })

    /*convert RDD to DataFrame*/
    val structFieldsBuf = ArrayBuffer.empty[StructField]
    structFieldsBuf += StructField(keyColName, StringType, false)
    for(id <- sparseFeaturesID) {
      structFieldsBuf += StructField(sparseFeaturesPrefix + id, DoubleType, false)
    }
    structFieldsBuf += StructField(dateColName, StringType, false)
    val schema = StructType(structFieldsBuf)

    /* return sparsedDF is something like below if sparseFeaturesPrefix = "prefix_" and sparseFeaturesID = Array["0", "1," "2", "3", "4"]:
    +--------+--------+--------+--------+--------+--------+----------+
    |     key|prefix_0|prefix_1|prefix_2|prefix_3|prefix_4|         d|
    +--------+--------+--------+--------+--------+--------+----------+
    |11700777|     1.0|     0.0|     1.0|     1.0|     0.0|2016-12-22|
    | 8600570|     1.0|     0.0|     0.0|     1.0|     0.0|2016-12-22|
    */
    val oneHotEncodedDF = MySparkContext.hiveContext.createDataFrame(sparsedRDD, schema)
    oneHotEncodedDF
  }

  def VectorizeFeatureColumns(df:DataFrame, labelColName:String, features:Array[String]): DataFrame = {
    // sample table with features turned into one vector
    import org.apache.spark.ml.feature.{VectorAssembler}
    // user feature prefix in combined table
    //val u_ = "u_"
    // product feature prefix in combined table
    //val p_ = "p_"
    //val features = Array(u_ + "VIPFlag", u_ + "Grade", u_ + "GenerousHTL", u_ + "GenerousFLT", u_ + "CustomerValue", u_ + "CtripProfits", u_ + "Crown", p_ + "CommentCount", p_ + "CommentScore", p_ + "ClickRatio", p_ + "TravelCount", p_ + "TravelDays", p_ + "SaleMode", p_ + "Level", p_ + "Pattern");

    val assembler = new VectorAssembler().setInputCols(features).setOutputCol("features")
    // the feature columns vectorized dataframe
    val featureVectorizedDF = assembler.transform(df).select(labelColName, "features")
    featureVectorizedDF
  }

  def splitData(df:DataFrame):(DataFrame, DataFrame) = {
    val startTimeForTrain = ConfigManager.conf("startTimeForTrain")
    val endTimeForTrain = ConfigManager.conf("endTimeForTrain")
    val startTimeForTest = ConfigManager.conf("startTimeForTest")
    val endTimeForTest = ConfigManager.conf("endTimeForTest")
    val dfForTrain = df.repartition(ConfigManager.conf("repartitionNum").toInt).filter(s"d>='$startTimeForTrain' and d<='$endTimeForTrain'")
    val dfForTest = df.repartition(ConfigManager.conf("repartitionNum").toInt).filter(s"d>='$startTimeForTest' and d<='$endTimeForTest'")
    (dfForTrain, dfForTest)
  }

  def sampling(originDF:DataFrame, fraction:Double, seed: Long) = {

    val positive = originDF.filter(s"${ConfigManager.conf("labelColName")} = ${ConfigManager.conf("positiveValue").toInt}")
    val negtive = originDF.filter(s"${ConfigManager.conf("labelColName")} = ${ConfigManager.conf("negtiveValue").toInt}")
    val keptNegtive = negtive.sample(withReplacement = false, fraction, seed)//.repartition(ConfigManager.repartitionNum1)

    val negCount = keptNegtive.count().toDouble
    val posCount = positive.count().toDouble
    val scalePosWeight = negCount/posCount
    println("Negative Sampling Rate: " + fraction)
    println("Negative sample numbers after sampling: " + negCount) // 2839008
    println("Positive sample numbers after sampling: " + posCount) // 1353412
    println("scale_pos_weight should be(num(neg)/num(pos)): " + scalePosWeight + " =========")

    (positive.repartition(ConfigManager.conf("repartitionNum").toInt).unionAll(keptNegtive.repartition(ConfigManager.conf("repartitionNum").toInt)), scalePosWeight)
  }

  def convertToRDDofMLBLabeledPoint(df:DataFrame):RDD[org.apache.spark.mllib.regression.LabeledPoint] = {
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      org.apache.spark.mllib.regression.LabeledPoint(row.getInt(0).toDouble, Vectors.dense(buf.toArray))
    })
    rdd
  }

  def convertToRDDofMLBSparseVecLabeledPoint(df:DataFrame):RDD[org.apache.spark.mllib.regression.LabeledPoint] = {
    val vecSize = df.columns.length - 1
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val nonZeroValuesIndices = ArrayBuffer.empty[Int]
      val valuesBuf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        val value = row.getDouble(i)
        if(/*value != 0.0*/ value != -9999.99) { // need to modify this condition because 0.0 could also be normal values!!!!!
          nonZeroValuesIndices += i - 1
          valuesBuf += row.getDouble(i)
        }
      }
      org.apache.spark.mllib.regression.LabeledPoint(row.getInt(0).toDouble, Vectors.sparse(vecSize, nonZeroValuesIndices.toArray, valuesBuf.toArray))
    })
    rdd
  }

  def convertToRDDofDMLCLabeledPoint(df:DataFrame):RDD[ml.dmlc.xgboost4j.LabeledPoint] = {
    val rdd = df.rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double]
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      ml.dmlc.xgboost4j.LabeledPoint.fromDenseVector(row.getInt(0).toFloat, buf.toArray.map(_.toFloat))
    })
    rdd
  }

  def convertToRDDofLabeledPoint(rdd:RDD[Row]):RDD[LabeledPoint] = {
    val rddl = rdd.repartition(ConfigManager.conf("repartitionNum").toInt).map(row => {
      val buf = ArrayBuffer.empty[Double];
      for(i <- 1 until row.size) {
        buf += row.getDouble(i)
      }
      LabeledPoint(row.getInt(0).toDouble, Vectors.dense(buf.toArray));
    })
    rddl
  }

  def dumpModel(model: XGBoostModel) = {
    val strModel = model.booster.getModelDump();
    strModel;
  }

  def createFeatureMap(savePath:String, featureNames:Array[String]): Unit = {
    val writer = new PrintWriter(savePath, "UTF-8")
    for (i <- 0 until featureNames.length) {
      writer.print(i + "\t" + featureNames(i) + "\t" + "q\n")
    }
    writer.close()
  }

  def saveDumpModel(modelPath: String, modelInfos: Array[String]): Unit = {
    val writer = new PrintWriter(modelPath, "UTF-8")
    for (i <- 0 until modelInfos.length) {
      writer.print(s"booster[$i]:\n")
      writer.print(modelInfos(i))
    }
    writer.close()
  }

  def saveModel(savePath:String, model:XGBoostModel) = {
    model.saveModelAsHadoopFile(savePath)//(MySparkContext.sc);
  }

  def convert(rdd: RDD[org.apache.spark.mllib.regression.LabeledPoint], isFeatureDenseVector:Boolean = true): RDD[ml.dmlc.xgboost4j.LabeledPoint] = {
    rdd.map(labelPoint => {
      if(isFeatureDenseVector) {
        ml.dmlc.xgboost4j.LabeledPoint.fromDenseVector(labelPoint.label.toFloat, labelPoint.features.toArray.map(_.toFloat))
      }
      else {
        ml.dmlc.xgboost4j.LabeledPoint.fromSparseVector(labelPoint.label.toFloat, labelPoint.features.asInstanceOf[SparseVector].indices, labelPoint.features.asInstanceOf[SparseVector].values.map(_.toFloat))//(labelPoint.label.toFloat, labelPoint.features.toArray.map(_.toFloat))
      }
    })
  }

  // from stackoverflow, alternative method of model predict
  // http://stackoverflow.com/questions/36770190/xgboost-4j-by-dmlc-on-spark-1-6-1
  def labelPredict(testSet: RDD[ml.dmlc.xgboost4j.LabeledPoint], useExternalCache: Boolean = false, _booster: XGBoostModel): RDD[(Double, Double)] = {
    import ml.dmlc.xgboost4j.scala.spark.{DataUtils}
    val booster = _booster.asInstanceOf[XGBoostModel].booster
    val broadcastBooster = testSet.sparkContext.broadcast(booster)
    testSet.mapPartitions { testData =>
      val (auxiliaryIterator, testDataIterator) = testData.duplicate
      val testDataArray = auxiliaryIterator.toArray
      val prediction = broadcastBooster.value.predict(new ml.dmlc.xgboost4j.scala.DMatrix(testDataIterator)).flatten
      testDataArray
        .zip(prediction)
        .map {
          case (labeledPoint, predictionValue) =>
            (predictionValue.toDouble, labeledPoint.label.toDouble)
        }.toIterator
    }
  }

  def auc(predictionAndLabels:RDD[(Double,Double)]) = {
    val metrics = new BinaryClassificationMetrics(predictionAndLabels)
    val aucResult = metrics.areaUnderROC
    aucResult
  }
}


package MavenScala

import scala.xml.XML

/**
 * Created by wenlong on 2016/12/16
 */

object ConfigManager {
  val conf = scala.collection.mutable.Map[String,String]()

  def loadConfigManager(path:String) = {
    /* Load Configuration Manager*/
    val configManager = XML.loadFile(path)
    configManager.foreach(rootNode => {
      val configManagerItems = rootNode\\"ConfigManager"\\"ConfigItem"

      /* Config Items */
      configManagerItems.foreach(targetNode => {
        val itemName = (targetNode\\"@itemName").text
        val itemValue = targetNode.text
        ConfigManager.conf(itemName) = itemValue
      })
    })
  }
}





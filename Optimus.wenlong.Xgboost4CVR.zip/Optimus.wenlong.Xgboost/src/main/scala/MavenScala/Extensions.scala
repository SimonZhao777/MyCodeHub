package MavenScala

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.DataType

/**
  * Created by zhaowl on 2016/12/27.
  */

// DataFrame Extension methods
object MyExtensions {
  implicit class RichDataFrame(baseDF: DataFrame) {
    // user feature prefix in combined table
    val userPrefix = "u_"
    // product feature prefix in combined table
    val prodPrefix = "p_"

    // Join product tables based on sampleSPDPDF
    def prodTableJoin(joinDF: DataFrame, featureColRename: String, isSingleValueCol:Boolean = true, joinType: String = "left"): DataFrame = {
      if(isSingleValueCol) {
        baseDF.repartition(ConfigManager.conf("repartitionNum").toInt)
          .join(joinDF, baseDF("pkgid") === joinDF("key") && baseDF("d") === joinDF("p_d"), joinType)
          .withColumnRenamed("value", prodPrefix+featureColRename)
          .drop("key")
          .drop("p_d")
      }
      else {
        baseDF.repartition(ConfigManager.conf("repartitionNum").toInt)
          .join(joinDF, baseDF("pkgid") === joinDF("key") && baseDF("d") === joinDF("p_d"), joinType)
          .drop("key")
          .drop("p_d")
      }
    }

    // Join user tables based on sampleSPDPDF
    def userTableJoin(joinDF: DataFrame, featureColRename: String, isSingleValueCol:Boolean = true, joinType: String = "left"): DataFrame = {
      if(isSingleValueCol) {
        baseDF.repartition(ConfigManager.conf("repartitionNum").toInt)
          .join(joinDF, baseDF("uid") === joinDF("key") && baseDF("d") === joinDF("u_d"), joinType)
          .withColumnRenamed("value", userPrefix+featureColRename)
          .drop("key")
          .drop("u_d")
      }
      else {
        baseDF.repartition(ConfigManager.conf("repartitionNum").toInt)
          .join(joinDF, baseDF("uid") === joinDF("key") && baseDF("d") === joinDF("u_d"), joinType)
          .drop("key")
          .drop("u_d")
      }
    }

    // cast column type
    def castColumnTo(columnName: String, toType: DataType ) : DataFrame = {
      baseDF.repartition(ConfigManager.conf("repartitionNum").toInt).withColumn(columnName, baseDF(columnName).cast(toType))
    }

    // Select an array of features
    def featureSelect(label:String, features:Array[String]): DataFrame = {
      baseDF.select(label, features:_*)
    }
  }
}

package MavenScala

import scala.xml.XML

/**
  * Created by zhaowl on 2017/1/17.
  */
object XGBConfig {
  val confMap = scala.collection.mutable.Map[String,String]()

  def loadXGBConfig(path:String) = {
    val xgbConfigMap = XML.loadFile(path)
    xgbConfigMap.foreach(rootNode => {
      val xgbConfigMapItems = rootNode\\"XGBConfigMap"\\"ConfigItem"

      /* Config Items */
      xgbConfigMapItems.foreach(targetNode => {
        val itemName = (targetNode\\"@itemName").text
        val itemValue = targetNode.text
        confMap(itemName) = itemValue
      })
    })
  }
}

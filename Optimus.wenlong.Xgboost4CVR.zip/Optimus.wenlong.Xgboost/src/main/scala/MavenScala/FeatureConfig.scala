package MavenScala

import scala.io.Source
import scala.xml.XML

/**
  * Created by zhaowl on 2017/1/17.
  */
object FeatureConfig {
  var sampleTableName:String = null
  val featureMatchingTableMap = scala.collection.mutable.Map[String, FeatureMatchingTable]()
  val featureMatchingArrayMap = scala.collection.mutable.Map[String, Array[String]]()
  val featureBinConfigTableMap = scala.collection.mutable.Map[String, FeatureMatchingTable]()
  val featureBinConfigArrayMap = scala.collection.mutable.Map[String, Array[(Double, Double)]]()
  val productSingleValueFeatureTableMap = scala.collection.mutable.Map[String, SingleValueFeatureTable]()
  val productMultiValueFeatureTableMap = scala.collection.mutable.Map[String, MultiValueFeatureTable]()
  val userSingleValueFeatureTableMap = scala.collection.mutable.Map[String, SingleValueFeatureTable]()
  val userMultiValueFeatureTableMap = scala.collection.mutable.Map[String, MultiValueFeatureTable]()

  def loadFeatureConfig(path:String): Unit = {
    /* Feature Configurations */
    val featureConfig = XML.loadFile(path)
    featureConfig.foreach(rootNode => {
      val sampleTable = rootNode\\"FeatureTables"\\"SampleTable"
      val featureMatchingTables = rootNode\\"FeatureTables"\\"FeatureMachingTables"\\"MatchingTable"
      val featureBinConfigTables = rootNode\\"FeatureTables"\\"FeatureBinConfigTables"\\"BinConfigTable"
      val prod_singleValueFeatureTables = rootNode\\"FeatureTables"\\"ProductFeatureTables"\\"SingleValueFeatureTables"\\"SingleValueFeatureTable"
      val prod_multiValueFeatureTables = rootNode\\"FeatureTables"\\"ProductFeatureTables"\\"MultiValueFeatureTables"\\"MultiValueFeatureTable"
      val user_singleValueFeatureTables = rootNode\\"FeatureTables"\\"UserFeatureTables"\\"SingleValueFeatureTables"\\"SingleValueFeatureTable"
      val user_multiValueFeatureTables = rootNode\\"FeatureTables"\\"UserFeatureTables"\\"MultiValueFeatureTables"\\"MultiValueFeatureTable"

      /* Sample Table */
      sampleTableName = sampleTable.text

      /* Feature Matching Tables */
      featureMatchingTables.foreach(targetNode => {
        val tableTagName = (targetNode\\"@tableTagName").text
        val tableName = targetNode.text
        FeatureConfig.featureMatchingTableMap(tableTagName)
          = new FeatureMatchingTable(tableTagName, tableName)
      })

      /* Convert Feature Matching Tables Index Into Array[String] And Store In FeatureConfig.featureMatchingArrayMap */
      featureMatchingTableMap.foreach( table => {
        val tableTagName = table._1
        val featureMatchingTable = table._2 // NOW THE TABLE IS NOT HIVE TABLE ANYMORE, INSTEAD IT'S CONFIG FILES IN: hdfs://ns/user/vacml/zzy/cvr/featureconf/
        //val tableDF = MySparkContext.hiveContext.sql("select * from " + featureMatchingTable.matchingTableName)
        var featurePossibleValueList = Set[String]()
        Source.fromFile(featureMatchingTable.matchingTableName, "UTF-8").getLines.foreach(s => {
          if(s.trim.nonEmpty) {
            val featureBinArray = s.split("#")
            if(featureBinArray.length != 2) throw new Exception("Wrong Configuration!")
            else {
              featurePossibleValueList += featureBinArray(1)
            }
          }
        })
        FeatureConfig.featureMatchingArrayMap(tableTagName) = featurePossibleValueList.toArray
      })

      /* Feature Bin Configuration Tables */
      featureBinConfigTables.foreach(targetNode => {
        val tableTagName = (targetNode\\"@tableTagName").text
        val tableName = targetNode.text
        FeatureConfig.featureBinConfigTableMap(tableTagName)
          = new FeatureMatchingTable(tableTagName, tableName)
      })

      /* Double value parser */
      def parseDouble(s: String) = {
        try { Some(s.toDouble) } catch { case _ => None }
      }
      /* Convert Feature Bin Configuration Tables Into Array[String] And Store In FeatureConfig.featrueBinConfigArrayMap */
      featureBinConfigTableMap.foreach( table => {
        val tableTagName = table._1
        val featureBinConfigTable = table._2 // NOW THE TABLE IS NOT HIVE TABLE ANYMORE, INSTEAD IT'S CONFIG FILES IN: hdfs://ns/user/vacml/zzy/cvr/featureconf/
        //val tableDF = MySparkContext.hiveContext.sql("select * from " + featureMatchingTable.matchingTableName)
        var featurePossibleValueList = Set[(Double, Double)]()
        Source.fromFile(featureBinConfigTable.matchingTableName, "UTF-8").getLines.foreach(s => {
          if(s.trim.nonEmpty) {
            val featureBinArray = s.split("~")
            if(featureBinArray.length != 2) throw new Exception("Wrong Configuration, there must be lower and upper bounds in each line.")
            else {
              val lowerBound = parseDouble(featureBinArray(0).trim)
              val upperBound = parseDouble(featureBinArray(1).trim)
              if(lowerBound.isEmpty || upperBound.isEmpty) throw new Exception("Wrong Configuration, lower and upper bounds must be double type.")
              else {
                featurePossibleValueList += new Tuple2(lowerBound.get, upperBound.get)
              }
            }
          }
        })
        FeatureConfig.featureBinConfigArrayMap(tableTagName) = featurePossibleValueList.toArray
      })

      /* Product Feature Tables */
      /* Single Value */
      prod_singleValueFeatureTables.foreach(targetNode => {
        val featureColName = (targetNode\\"@featureColName").text
        val featureRename = (targetNode\\"@featureRename").text
        val featureBinConfigTableTagName = (targetNode\\"@binConfigTableTagName").text
        val featureTableName = targetNode.text
        FeatureConfig.productSingleValueFeatureTableMap(featureRename)
          = new SingleValueFeatureTable(featureColName, featureRename, featureBinConfigTableTagName, featureTableName)
      })
      /* Multi Value */
      prod_multiValueFeatureTables.foreach(targetNode => {
        val featureMatchingTableTagName = (targetNode\\"@featureMatchingTableTagName").text
        val featuresRenamePrefix = (targetNode\\"@featuresRenamePrefix").text
        val featureTableName = targetNode.text
        FeatureConfig.productMultiValueFeatureTableMap(featuresRenamePrefix)
          = new MultiValueFeatureTable(featureMatchingTableTagName, featuresRenamePrefix, featureTableName)
      })

      /* User Feature Tables */
      /* Single Value */
      user_singleValueFeatureTables.foreach(targetNode => {
        val featureColName = (targetNode\\"@featureColName").text
        val featureRename = (targetNode\\"@featureRename").text
        val featureBinConfigTableTagName = (targetNode\\"@binConfigTableTagName").text
        val featureTableName = targetNode.text
        FeatureConfig.userSingleValueFeatureTableMap(featureRename)
          = new SingleValueFeatureTable(featureColName, featureRename, featureBinConfigTableTagName, featureTableName)
      })
      /* Multi Value */
      user_multiValueFeatureTables.foreach(targetNode => {
        val featureMatchingTableTagName = (targetNode\\"@featureMatchingTableTagName").text
        val featuresRenamePrefix = (targetNode\\"@featuresRenamePrefix").text
        val featureTableName = targetNode.text
        FeatureConfig.userMultiValueFeatureTableMap(featuresRenamePrefix)
          = new MultiValueFeatureTable(featureMatchingTableTagName, featuresRenamePrefix, featureTableName)
      })
    })
  }
}

class SingleValueFeatureTable(feature_ColName:String, feature_Rename:String, feature_BinConfigTableTagName:String, feature_TableName:String) {
  val featureColName = feature_ColName
  val featureRename = feature_Rename
  val featureBinConfigTableTagName = feature_BinConfigTableTagName
  val featureTableName = feature_TableName
}

class MultiValueFeatureTable(feature_MatchingTableTagName:String, features_RenamePrefix:String, feature_TableName:String) {
  val featureMatchingTableTagName = feature_MatchingTableTagName
  val featuresRenamePrefix = features_RenamePrefix
  val featureTableName = feature_TableName
}

class FeatureMatchingTable(tableTagName:String, featureMatchingTableName:String) {
  val matchingTableTagName = tableTagName
  val matchingTableName = featureMatchingTableName
}

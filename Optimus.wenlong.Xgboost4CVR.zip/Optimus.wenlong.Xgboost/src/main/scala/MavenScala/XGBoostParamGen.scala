package MavenScala

/**
  * Created by zhaowl on 2017/1/7.
  */
object XGBoostParamGen {

  val gridSearchParamsMap = scala.collection.mutable.Map( // the order is tuning order
    "eta" -> (0.04, 0.3, 0.0, 0.0, false),// (stepSize, max, bestAUC, etaWithBestAUC, allEtaIterated)
    "round" -> (20.0, 6000.0, 0.0, 0.0, false),
    "max_depth" -> (1.0, 17.0, 0.0, 0.0, false),
    "min_child_weight" -> (1.0, 10.0, 0.0, 0.0, false),
    "gamma" -> (1.0, 10.0, 0.0, 0.0, false),
    "subsample" -> (0.1, 1.0, 0.0, 0.0, false),
    "colsample_bytree" -> (0.1, 1.0, 0.0, 0.0, false),
    // then "reg_alpha"
    // reduing learning rate
    "scale_pos_weight" -> (0.1, 10.0, 0.0, 0.0, false),
    "max_delta_step" -> (1.0, 10.0, 0.0, 0.0, false))

  // return (XGBConfigMap, round, currentModifiedParameter, areAllPossibleConfigIterated)
  def getGridSearchUpdatedXGBParams(oldXGBConfigMap: scala.collection.immutable.Map[String, Any], oldRound: Integer, fixedParam:String): (scala.collection.immutable.Map[String, Any], Integer, String, Boolean) = {

    if(fixedParam == "eta") { // fix ETA and get best Round
      if(!gridSearchParamsMap("round")._5) { // if new Parameter of Round could be given, then return new round
        if(oldRound < gridSearchParamsMap("round")._2
          && (oldRound + gridSearchParamsMap("round")._1) <= gridSearchParamsMap("round")._2) {
          return (oldXGBConfigMap, (oldRound + gridSearchParamsMap("round")._1).toInt, "round", false)
        }
        else { // if new Round could not be given, then modify the allRoundIterated to true and proceed to next parameter tuning
          val temp = gridSearchParamsMap("round")
          gridSearchParamsMap("round") = (temp._1, temp._2, temp._3, temp._4, true)
          return (oldXGBConfigMap, oldRound, "round", true)
        }
      }
    }

    /*if(!gridSearchParamsMap("eta")._5) { // keep the Round with best AUC performance and then tune the eta
      if(oldXGBConfigMap("eta").asInstanceOf[Double] < gridSearchParamsMap("eta")._2
          && (oldXGBConfigMap("eta").asInstanceOf[Double] + gridSearchParamsMap("eta")._1) <= gridSearchParamsMap("eta")._2) {
        val newValue = oldXGBConfigMap("eta").asInstanceOf[Double] + gridSearchParamsMap("eta")._1
        val newXGBConfigMap = updatedXGBConfigMap(oldXGBConfigMap, "eta", newValue)
        return (newXGBConfigMap, oldRound, "eta", false)
      }
      else {

      }

    }

    if(oldXGBConfigMap("max_depth").asInstanceOf[Integer] < gridSearchParamsMap("max_depth")._2
      && (oldXGBConfigMap("max_depth").asInstanceOf[Integer] + gridSearchParamsMap("max_depth")._1) <= gridSearchParamsMap("max_depth")._2) {
      val newValue = oldXGBConfigMap("max_depth").asInstanceOf[Integer] + gridSearchParamsMap("max_depth")._1.toInt
      val newXGBConfigMap = updatedXGBConfigMap(oldXGBConfigMap, "max_depth", newValue)
      return (newXGBConfigMap, oldRound, "max_depth", false)
    }*/

    // TODO: ADD MORE GRID SEARCH RULES
    //

    return (oldXGBConfigMap, oldRound, "",true)
  }

  def updateXGBParams(testDataAUC:Double, modifiedParamName:String, round:Int, configMap:scala.collection.immutable.Map[String, Any]): Unit = {
    if (testDataAUC > gridSearchParamsMap(modifiedParamName)._3) {
      val temp = gridSearchParamsMap(modifiedParamName)
      if(modifiedParamName == "round") {
        gridSearchParamsMap(modifiedParamName) = (temp._1, temp._2, testDataAUC, round, temp._5)
      } else {
        gridSearchParamsMap(modifiedParamName) = (temp._1, temp._2, testDataAUC, configMap(modifiedParamName).asInstanceOf[Double], temp._5)
      }
    }
  }

  /*private def updatedXGBConfigMap(oldXGBConfigMap: scala.collection.immutable.Map[String, Any], key: String, newValue: Any): scala.collection.immutable.Map[String, Any] = {
    val newXGBConfigMapTemp = oldXGBConfigMap
    newXGBConfigMapTemp(key) = newValue
  }*/
}
